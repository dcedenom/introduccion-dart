# Ejercicios introductorios de Dart

Estos ejercicios los expliqué en mi curso de Flutter que pueden encontrar [en DevTalles.com](https://cursos.devtalles.com/)
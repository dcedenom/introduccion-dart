void main() {
  
//   var myName = 'Fernando';
//   late final myName;
//   String myName = 'Fernando';
  const myName = 'Fernando';
    
  
  print('Hola $myName');
  print('Hola ${ myName.toUpperCase() }');
  print('Hola ${ 1 + 1 }');
}